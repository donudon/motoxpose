<nav class="navbar navbar-fixed-top" role="navigation">
	  <div class="container-fluid">
	    <div class="navbar-header">
	    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class = "sr-only">Toggle navigation</span>
				<span class="icon-bar" style="background-color:white;"></span>
		        <span class="icon-bar" style="background-color:white;"></span>
		        <span class="icon-bar" style="background-color:white;"></span>                        
			</button>
	    	<a class="navbar-brand" href="#"><img src="img/MotoXTT.jpg" alt="MotoXpose" width="50px"></a>
	    </div>
	    <div class="collapse navbar-collapse" id="myNavbar">
		    <ul class="nav navbar-nav">
		    	<!-- <li><a href="/" style="background-color:white;color:black;padding-top:25px;margin-left:-20px;height:65px;margin-top:-10;font-size:8px;"><em>/ <strong>Indonesia's</strong> largest <strong>Sports Bike</strong> Culture</em></a></li> -->
				<li><a href="/">HOME</a></li>
				<li><a href="/gal">GALLERY</a></li>
				<li><a href="/blogf">BLOG</a></li>
				<li><a href="#">GARAGE</a></li>
				<li><a href="/aboutus" class="cust">ABOUT US</a></li>
				<li><a href="/contactus">CONTACT</a></li>

		    </ul>
		    <ul class="nav navbar-nav navbar-right">
				<li><a href="#"><img src="img/facebook.png" alt="Facebook" id="hov"></a></li>
				<li><a href="#"><img src="img/instagram.png" alt="Instagram" id="hov"></a></li>
				<li><a href="#"><img src="img/youtube.png" alt="Youtube" id="hov"></a></li>
			</ul>
		</div>
	  </div>
	</nav>