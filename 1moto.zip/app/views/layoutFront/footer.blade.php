 <footer >
    <div class="row">
        <div class="col-md-2">
            <p style="color:white;">About</p><Br>
            <img src="img/logo.jpg" width="60%">
            <p style="color:white;">asdkh asdouhasd oiasd oasdh asdoihasd oiasd oashd asodisad oiasdo asdhiasdo ihasdoi h</p>
        </div>
        <div class="col-md-2">
            <p style="color:white;">Contact</p><Br>
            <p style="color:white;">asdkh asdouhasd oiasd oasdh asdoihasd oiasd oashd asodisad oiasdo asdhiasdo ihasdoi h</p>
        </div>
        <div class="col-md-8">

        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12">
            <hr class="featurette-divider" style="border-color:#ededed;">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p style="color:white;">OUR FRIENDS</p><Br>
        </div>
    </div>

</footer>