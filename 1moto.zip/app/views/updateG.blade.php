	@extends('layout.master')

	@section('content')
<body>
	@include('layout.header')
	<div class="container">
		<div class="col-md-12" align="center"><h2>Edit Gallery</h2></div>
		<form class="form-horizontal" action="../editG" method="post" enctype="multipart/form-data">
		    <div class="form-group">
		      <label for="txtUserid" class="col-md-3 control-label">Gallery ID</label>
		      <div class="col-md-6">
		        <input type="text" class="form-control" id="txtUserid" name="txtUserid" value="{{$data->id}}" readonly="readonly">
		      </div>
		    </div>
		    <div class="form-group" >
		    	<div class="col-md-3"></div>
		   		<div class="col-md-6">
                    <img src="../img/gallery/{{$data->thumbnail}}">
                </div>        
            </div>
		    <div class="form-group" >
                <label for="txtThumbnail" class="col-md-3 control-label">Gallery Thumbnail</label>
                <div class="col-md-6">
                    <input type="file"  id="txtThumbnail" name="txtThumbnail"  value="{{$data->thumbnail}}">
                </div>
            </div>
            	<?php
			      $img = explode(",", $data->image);
			    ?>
            <div class="form-group" >
		    	<div class="col-md-3"></div>
		    	<div class="col-md-6">
		    	@foreach($img as $k => $v)
		            <img src="../img/gallery/{{$v}}">
		        @endforeach
                </div>        
            </div>
		    <div class="form-group" >
                <label for="txtImage" class="col-md-3 control-label">Gallery Images</label>
                <div class="col-md-6">
                    <input type="file" multiple  id="txtImage[]" name="txtImage[]"  value="{{$data->thumbnail}}">
                </div>
            </div>
		    <div class="form-group">
		      <label for="txtUsername" class="col-md-3 control-label">Gallery Caption</label>
		      <div class="col-md-6">
		        <input type="text" class="form-control" id="txtUsername" name="txtUsername" value="{{$data->caption}}" placeholder="Name">
		        <span class="text-danger">{{$errors->first('name')}} </span>
		      </div>
		    </div>
		    <div class="form-group">
		      <div class="col-md-10 col-md-offset-2">
		        <button type="submit" class="btn btn-primary">Update</button>
		        </div>
		    </div>
		</form>
	</div>
</body>
@stop
</html>
