  <form class="navbar-form navbar-left" method="{{$title}}" role="search">
    <div class="form-group">
      <input type="text" class="form-control" id="txtSearch" name="search" placeholder="Search">
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>