	@extends('layout.master')

	@section('content')
<body>
	@include('layout.header')
	<div class="container">
		<div class="col-md-12" align="center"><h2>Add New Gallery</h2></div>
		<form class="form-horizontal" action="addG" method="post" enctype="multipart/form-data">
		    <div class="form-group">
		      <label for="txtUserid" class="col-md-3 control-label">Gallery ID</label>
		      <div class="col-md-6">
		        <input type="text" class="form-control" id="txtUserid" name="txtUserid" value="{{$id}}" readonly="readonly">
		      </div>
		    </div>
		    <div class="form-group" >
		      <label for="txtThumb" class="col-md-3 control-label">Gallery Thumbnail</label>
		      <div class="col-md-6">
		        <input type="file"  id="txtThumb" name="txtThumb" value=""required>
		      </div>
		    </div>
			<div class="form-group" >
				<label for="txtImage" class="col-md-3 control-label">Customer Photo</label>
				<div class="col-md-6">
					<input type="file"  id="txtImage" name="txtImage[]" multiple value="{{Input::old('txtImage')}}"required>
				</div>
			</div>
		    <div class="form-group">
		      <label for="txtCaption" class="col-md-3 control-label">Image Caption</label>
		      <div class="col-md-6">
		        <input type="text" class="form-control" id="txtCaption" name="txtCaption" value="{{Input::old('txtUsername')}}" placeholder="Name">
		        <span class="text-danger">{{$errors->first('name')}} </span>
		      </div>
		    </div>
		    <div class="form-group">
		      <div class="col-md-10 col-md-offset-2">
		        <button type="reset" class="btn btn-default">Cancel</button>
		        <button type="submit" class="btn btn-primary">Register</button>
		        </div>
		    </div>
		</form>

	</div>
</body>
@stop
</html>
