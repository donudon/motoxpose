<?php
require 'vendor/autoload.php';

use Intervention\Image\ImageManagerStatic as Image;

	class InsertAController extends BaseController {

	public $restful = true;

	public function getIndex()
	{
		$ms_ads = MsAds::orderBy('id', 'desc')->first();
		$newID = $ms_ads->id +1;
		$title = "Add New";
		$user = Auth::user()->username;
		return View::make('insertA', array('title' => $title, 'id'=>$newID, 'user'=>$user, 'status'=>'an'));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_customer));
	}

	public function doInsert()
	{
		if (Input::hasFile('txtImage'))
		{
		    //
		    $file = Input::file('txtImage');
			$filename = Input::file('txtImage')->getClientOriginalName();
			$filename= Input::get('txtUserid').$filename;
			$dest = public_path().'/img/ads/';
			$nDest=$dest."/%s";
			$result=$file->move($dest, $filename);
			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			DB::table('ms_ads')->insert(
			    array(  'image' => $filename,
			    		'startdate'=> Input::get('txtSDate'),
			    		'enddate'=> Input::get('txtEDate')
			    )
			);
			return Redirect::to('/ads');
		}
		
	}
}
?>