<?php
require 'vendor/autoload.php';

// import the Intervention Image Manager Class
use Intervention\Image\ImageManagerStatic as Image;

	class UpdateAController extends BaseController {

	public $restful = true;

	public function getIndex($id)
	{
		$ms_ads = DB::table('ms_ads')->where('id', $id)->first();
		//$newID = $ms_ads->id +1;
		$title = "Update";
		$user = Auth::user()->username;
		return View::make('updateA', array('title' => $title,'data'=>$ms_ads,'user'=>$user));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_customer));
	}

	public function doUpdate()
	{
		$id = Input::get('txtAdsId');
		if (Input::hasFile('txtImage'))
		{
		    //
		    //delete file first
		    //=================
		    $del = DB::table('ms_ads')->where('id', Input::get('txtAdsId'))->first();
			$data = array('data' => $del->image );
			$destD = public_path().'\img\ads\\';
			File::delete($destD.$data['data']);

			//update new photo file
			//======================
		    $file = Input::file('txtImage');
			$filename = Input::file('txtImage')->getClientOriginalName();
			$filename= Input::get('txtAdsId').$filename;
			$dest = public_path().'/img/ads/';
			$nDest=$dest."/%s";
			$result=$file->move($dest, $filename);

			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			DB::table('ms_ads')
	            ->where('id', Input::get('txtAdsId'))
	            ->update(array(
	            	'enddate' => Input::get('txtEDate'),
			        'image' => $filename
			    )
			);
			return Redirect::to('/ads');
		}else{
			DB::table('ms_ads')
	            ->where('id', Input::get('txtAdsId'))
	            ->update(array(
	            	'enddate' => Input::get('txtEDate')
			    )
			);
	        return Redirect::to('/ads');
		}
		
	}
}
?>