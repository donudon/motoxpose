<?php
require 'vendor/autoload.php';

use Intervention\Image\ImageManagerStatic as Image;

	class InsertGController extends BaseController {

	public $restful = true;

	public function getIndex()
	{
		$ms_gallery = MsGallery::orderBy('id', 'desc')->first();
		$newID = $ms_gallery->id +1;
		$title = "Add New";
		$user = Auth::user()->username;
		return View::make('insertG', array('title' => $title, 'id'=>$newID, 'user'=>$user, 'status'=>'an'));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_customer));
	}

	public function doInsert()
	{

		if (Input::hasFile('txtThumb'))
		{
			//
			$file = Input::file('txtThumb');
			$filename = Input::file('txtThumb')->getClientOriginalName();
			$filename= Input::get('txtUserid').'thumb'.$filename;
			$dest = public_path().'/img/gallery/';
			$nDest=$dest."/%s";
			$result = $file->move($dest, $filename);
			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			if (Input::hasFile('txtImage'))
			{
				//
				$files = Input::file('txtImage');
				$storeName="";
				foreach ($files as $keys => $val) {
					$filenames[$keys]['name'] = $val->getClientOriginalName();
					$filenames[$keys]['name'] = Input::get('txtUserid').$keys.$filenames[$keys]['name'];
					$dest = public_path().'/img/gallery/';
					$val->move($dest, $filenames[$keys]['name']);
					if ($keys== count($files)-1) {
						$storeName = $storeName.$filenames[$keys]['name'];
					}else{
						$storeName = $storeName.$filenames[$keys]['name'].",";
					}

				}
			}
			DB::table('ms_gallery')->insert(
				array(  'thumbnail' => $filename,
					'image' => $storeName,
					'caption' => Input::get('txtCaption')
				)
			);
			return Redirect::to('/gallery');
		}

		
	}
}
?>