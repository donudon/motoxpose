<?php
require 'vendor/autoload.php';

use Intervention\Image\ImageManagerStatic as Image;

	class InsertSController extends BaseController {

	public $restful = true;

	public function getIndex()
	{
		$ms_slider = MsSlider::orderBy('id', 'desc')->first();
		$newID = $ms_slider->id +1;
		$title = "Add New";
		$user = Auth::user()->username;
		return View::make('insertS', array('title' => $title, 'id'=>$newID, 'user'=>$user, 'status'=>'an'));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_customer));
	}

	public function doInsert()
	{

		if (Input::hasFile('txtImage'))
		{
		    //
		    $file = Input::file('txtImage');
			$filename = Input::file('txtImage')->getClientOriginalName();
			$filename= Input::get('txtUserid').$filename;
			$dest = public_path().'/img/slider/';
			$nDest=$dest."/%s";
			$result=$file->move($dest, $filename);
			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			DB::table('ms_slider')->insert(
			    array(  'image' => $filename
			    )
			);
			return Redirect::to('/slider');
		}
		
	}
}
?>