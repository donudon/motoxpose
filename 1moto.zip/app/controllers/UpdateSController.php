<?php
require 'vendor/autoload.php';

// import the Intervention Image Manager Class
use Intervention\Image\ImageManagerStatic as Image;

	class UpdateSController extends BaseController {

	public $restful = true;

	public function getIndex($id)
	{
		$ms_slider = DB::table('ms_slider')->where('id', $id)->first();
		//$newID = $ms_slider->id +1;
		$title = "Update";
		$user = Auth::user()->username;
		return View::make('updateS', array('title' => $title,'data'=>$ms_slider,'user'=>$user));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_slider));
	}

	public function doUpdate()
	{
		$id = Input::get('txtSliderid');
		if (Input::hasFile('txtImage'))
		{
		    //
		    //delete file first
		    //=================
		    $del = DB::table('ms_slider')->where('id', Input::get('txtSliderid'))->first();
			$data = array('data' => $del->image );
			$destD = public_path().'\img\slider\\';
			File::delete($destD.$data['data']);

			//update new photo file
			//======================
		    $file = Input::file('txtImage');
			$filename = Input::file('txtImage')->getClientOriginalName();
			$filename= Input::get('txtSliderid').$filename;
			$dest = public_path().'/img/slider/';
			$nDest=$dest."/%s";
			$result=$file->move($dest, $filename);

			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			DB::table('ms_slider')
            ->where('id', Input::get('txtSliderid'))
            ->update(array(
		        'image' => $filename
		    )
		);
		return Redirect::to('/slider');
		}
		
	}
}
?>