<?php
require 'vendor/autoload.php';

// import the Intervention Image Manager Class
use Intervention\Image\ImageManagerStatic as Image;

	class UpdateGController extends BaseController {

	public $restful = true;

	public function getIndex($id)
	{
		$ms_gallery = DB::table('ms_gallery')->where('id', $id)->first();
		//$newID = $ms_gallery->id +1;
		$title = "Update";
		$user = Auth::user()->username;
		return View::make('updateG', array('title' => $title,'data'=>$ms_gallery,'user'=>$user));
		//return View::make('insert', array('title' => $title, 'data'=>$ms_gallery));
	}

	public function doUpdate()
	{
		$id = Input::get('txtUserid');
		if (Input::hasFile('txtThumbnail'))
		{
		    //
		    //delete file first
		    //=================
		    $del = DB::table('ms_gallery')->where('id', Input::get('txtUserid'))->first();
			$data = array('data' => $del->thumbnail );
			$destD = public_path().'\img\gallery\\';
			File::delete($destD.$data['data']);
			$exp = explode(",", $del->image);
			foreach ($exp as $key => $value) {
				File::delete($destD.$value);
			}

			//update new photo file
			//======================
		    $file = Input::file('txtThumbnail');
			$filename = Input::file('txtThumbnail')->getClientOriginalName();
			$filename= Input::get('txtUserid').$filename;
			$dest = public_path().'/img/gallery/';
			$nDest=$dest."/%s";
			$result=$file->move($dest, $filename);
			$image = Image::make(sprintf($nDest, $filename))->fit(120, 160)->save();
			if (Input::hasFile('txtImage'))
			{
				//
				$files = Input::file('txtImage');
				$storeName="";
				foreach ($files as $keys => $val) {
					$filenames[$keys]['name'] = $val->getClientOriginalName();
					$filenames[$keys]['name'] = Input::get('txtUserid').$keys.$filenames[$keys]['name'];
					$dest = public_path().'/img/gallery/';
					$val->move($dest, $filenames[$keys]['name']);
					if ($keys== count($files)-1) {
						$storeName = $storeName.$filenames[$keys]['name'];
					}else{
						$storeName = $storeName.$filenames[$keys]['name'].",";
					}

				}
			}
			DB::table('ms_gallery')
	            ->where('id', Input::get('txtUserid'))
	            ->update(array(
			        'thumbnail' => $filename,
			        'image' => $storeName,
			        'caption' => Input::get('txtCaption')
			    )
			);
			return Redirect::to('/gallery');
		}else{
			DB::table('ms_gallery')
	            ->where('id', Input::get('txtUserid'))
	            ->update(array(	
			        'caption' => Input::get('txtCaption')
			    )
			);
			return Redirect::to('/gallery');
		}
		
	}
}
?>