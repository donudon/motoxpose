 <footer>
    <div class="row" style="background-color:#f1f1f2;height:240px;">
        <br><br>
        <div class="col-md-1">

        </div>
        <div class="col-md-10" style="margin-left:-34px">
            <div class="row" style="background-color:#f9ec59;width:90px;margin-bottom: 0px;-webkit-border-top-right-radius: 10px;">Our Friends</div>
            <div class="row" style="background-color:black;height: 140px;width:112%;">
                <div class="carousel slideF media-carousel" id="media">
                    <div class="carousel-inner">
                      <div class="item  active">
                        <div class="row">
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="https://lh3.googleusercontent.com/ATaAAutNX_0r8ekJqKdVR0iuqnnwh7qWh82XjoDArW2-pj_vgFk4KrBFTCLUze_skD-fnLhoL8qlTos=w1920-h1014"></a>
                          </div>          
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="https://lh5.googleusercontent.com/CN8gwvYjEYfFv5I0OC_1LC_1NmGuavwYoOKOUOEzCYQL_OukjLArwJJjKXHU49sRJoEfedgTfexim7o=w1920-h1014"></a>
                          </div>
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="https://lh4.googleusercontent.com/ce--EIxbgxULO6DMx5d-NmPPrvN8sO8fTvFHrJV0PezebUo1cp6a5X792xk76zd3DTScxMfYN--ngIY=w1920-h1014"></a>
                          </div>
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>          
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>         
                        </div>
                      </div>
                      <div class="item">
                        <div class="row">
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>          
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>          
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>
                          <div class="col-md-2">
                            <!-- <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a> -->
                          </div>      
                        </div>
                      </div>
                      <!-- <div class="item">
                        <div class="row">
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>          
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>          
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>
                          <div class="col-md-2">
                            <a class="thumbnail" href="#"><img alt="" src="http://placehold.it/150x150"></a>
                          </div>     
                        </div>
                      </div> -->
                    </div>
                    <a data-slide="prev" href="#media" class="left carousel-control">‹</a>
                    <a data-slide="next" href="#media" class="right carousel-control">›</a>
                </div> 
            </div>
        </div>
        <div class="col-md-1">

        </div>
    </div>
    <div class="row">
        <div class="col-md-1">

        </div>
        <div class="col-md-4" style="margin-left:-34px">
            <p style="color:black;"><br><br><em><strong>Indonesia's</strong> largest <strong>Sport Bike</strong> Culture</em></p>
        </div>
        <div class="col-md-7">

        </div>
        
    </div>
    <div class="row">
        <div class="col-md-12" align="center">
            <hr class="featurette-divider" style="border-color:#000000;width:1120px;">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12" style="font-size: 8px;margin-left: 72px;">
            <p style="color:black;margin-bottom:0px;">&copy 2017 MOTOXPOSE</p>
            <p style="color:black;">TRADEMARKS BELONG TO THEIR RESPECTIVE OWNERS. ALL RIGHT RESERVED</p><Br>
        </div>
    </div>

</footer>