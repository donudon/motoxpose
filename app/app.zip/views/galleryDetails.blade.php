@extends('layoutFront.master')

@section('content')
    <body>
    @include('layoutFront.header')

    <div class="jumbotron" style="background:url('img/S5.jpg') no-repeat top center;width:100%;height:500px;">
    </div>
    <div class="jumbotron">
        <div class="row">
            <div class="ads col-md-3" style="margin-top:-80px;"></div>
            <div class="ads col-md-6" style="margin-top:-80px;font-size:20px;"><br><br><a href="" id="h" class="hvr-underline-from-center" style="color:white;text-decoration:none;">Latest News</a> /  <a href="" class="hvr-underline-from-center" style="color:white;text-decoration:none;">Events</a> /  <a href="" class="hvr-underline-from-center" style="color:white;text-decoration:none;">MotoXpose Activities</a></div>
            <div class="ads col-md-3" style="margin-top:-80px;"></div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-8"><div class="divider"><strong><em>Latest News</em></strong></div>
                <div class="row">
                    <div class="col-sm-5">
                        <img src="img/S1.jpg" width="100%" height="225px">
                    </div>
                    <div class="col-sm-6 contentH" width="400px">
                        <p style="font-size:21px;line-height:120%;letter-spacing:2px;"><strong>VOLKSWAGEN ABU DHABI: OETTINGER BODY-KIT NOW FREE WITH SELECT GOLF GTI MODELS</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:2px;"><strong>DANIEL PRICE x JANUARY 23, 2017</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:1px;">Description asdasdsda asd asd asddasd asd as dsadasdasdada asd as as dasd asdsad a asd asd asasd asd asdsadas dasd asd asd asd asd asd asd a asdasdasdsad asdasdasd</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-5">
                        <img src="img/S1.jpg" width="100%" height="225px">
                    </div>
                    <div class="col-sm-6 contentH" width="400px">
                        <p style="font-size:21px;line-height:120%;letter-spacing:2px;"><strong>VOLKSWAGEN ABU DHABI: OETTINGER BODY-KIT NOW FREE WITH SELECT GOLF GTI MODELS</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:2px;"><strong>DANIEL PRICE x JANUARY 23, 2017</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:1px;">Description asdasdsda asd asd asddasd asd as dsadasdasdada asd as as dasd asdsad a asd asd asasd asd asdsadas dasd asd asd asd asd asd asd a asdasdasdsad asdasdasd</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-5">
                        <img src="img/S1.jpg" width="100%" height="225px">
                    </div>
                    <div class="col-sm-6 contentH" width="400px">
                        <p style="font-size:21px;line-height:120%;letter-spacing:2px;"><strong>VOLKSWAGEN ABU DHABI: OETTINGER BODY-KIT NOW FREE WITH SELECT GOLF GTI MODELS</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:2px;"><strong>DANIEL PRICE x JANUARY 23, 2017</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:1px;">Description asdasdsda asd asd asddasd asd as dsadasdasdada asd as as dasd asdsad a asd asd asasd asd asdsadas dasd asd asd asd asd asd asd a asdasdasdsad asdasdasd</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-5">
                        <img src="img/S1.jpg" width="100%" height="225px">
                    </div>
                    <div class="col-sm-6 contentH" width="400px">
                        <p style="font-size:21px;line-height:120%;letter-spacing:2px;"><strong>VOLKSWAGEN ABU DHABI: OETTINGER BODY-KIT NOW FREE WITH SELECT GOLF GTI MODELS</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:2px;"><strong>DANIEL PRICE x JANUARY 23, 2017</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:1px;">Description asdasdsda asd asd asddasd asd as dsadasdasdada asd as as dasd asdsad a asd asd asasd asd asdsadas dasd asd asd asd asd asd asd a asdasdasdsad asdasdasd</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-5">
                        <img src="img/S1.jpg" width="100%" height="225px">
                    </div>
                    <div class="col-sm-6 contentH" width="400px">
                        <p style="font-size:21px;line-height:120%;letter-spacing:2px;"><strong>VOLKSWAGEN ABU DHABI: OETTINGER BODY-KIT NOW FREE WITH SELECT GOLF GTI MODELS</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:2px;"><strong>DANIEL PRICE x JANUARY 23, 2017</strong></p>
                        <p style="font-size:12px;color:grey;letter-spacing:1px;">Description asdasdsda asd asd asddasd asd as dsadasdasdada asd as as dasd asdsad a asd asd asasd asd asdsadas dasd asd asd asd asd asd asd a asdasdasdsad asdasdasd</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <!-- SnapWidget -->
                <iframe src="https://snapwidget.com/embed/code/236393" class="snapwidget-widget" allowTransparency="true" frameborder="0" scrolling="no" style="border:none; overflow:hidden; width:390px; height:390px"></iframe>
            </div>
        </div>
    </div>
    @include('layoutFront.footer')